import React from 'react';

const signOut =() => {
  return (
    <div>
      <h1>signOut</h1>
    </div>
  );
}


export default signOut;