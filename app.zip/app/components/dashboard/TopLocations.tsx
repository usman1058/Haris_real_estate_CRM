"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface TopLocation {
  location: string
  demands: number
  inventory: number
}

const TopLocations = ({ locations = [] }: { locations?: TopLocation[] }) => {
  const maxDemands = Math.max(...locations.map((l) => l.demands || 1))

  return (
    <div className="space-y-4">
      {locations.map((loc, index) => (
        <div key={index} className="flex items-center space-x-4">
          <div className="flex items-center space-x-3 flex-1">
            <Avatar className="h-10 w-10">
              <AvatarFallback>
                {loc.location
                  .split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-1 flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium leading-none">{loc.location}</p>
                <Badge variant="secondary" className="text-xs">
                  {loc.inventory} inventories
                </Badge>
              </div>
              <Progress value={(loc.demands / maxDemands) * 100} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">{loc.demands} buyer demands</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

export default TopLocations
