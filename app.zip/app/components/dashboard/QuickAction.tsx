"use client"

import { useEffect, useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Plus, Users, Home, Landmark } from "lucide-react"

const QuickActions = () => {
  const [loading, setLoading] = useState(false)

  const [openDealer, setOpenDealer] = useState(false)
  const [openProperty, setOpenProperty] = useState(false)
  const [openDemand, setOpenDemand] = useState(false)
  const [openRecentDealers, setOpenRecentDealers] = useState(false)
  const [openRecentProperties, setOpenRecentProperties] = useState(false)

  const [dealer, setDealer] = useState({ name: "", email: "", phone: "", location: "" })
  const [property, setProperty] = useState({ title: "", location: "", size: "", price: "" })
  const [demand, setDemand] = useState({ location: "", size: "", budget: "" })

  const [recentDealers, setRecentDealers] = useState([])
  const [recentProperties, setRecentProperties] = useState([])

  useEffect(() => {
    if (openRecentDealers) {
      fetch("/api/dashboard?type=recent_dealers")
        .then((res) => res.json())
        .then((data) => setRecentDealers(data ?? []))
    }
    if (openRecentProperties) {
      fetch("/api/dashboard?type=recent_properties")
        .then((res) => res.json())
        .then((data) => setRecentProperties(data ?? []))
    }
  }, [openRecentDealers, openRecentProperties])

  const submitDealer = async () => {
    if (!dealer.name.trim()) return
    setLoading(true)
    try {
      await fetch("/api/dashboard?action=add_dealer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dealer),
      })
      setDealer({ name: "", email: "", phone: "", location: "" })
      setOpenDealer(false)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const submitProperty = async () => {
    const { title, location, size, price } = property
    if (!title || !location || !size || !price) return
    setLoading(true)
    try {
      await fetch("/api/dashboard?action=add_inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, location, size, price: parseFloat(price) }),
      })
      setProperty({ title: "", location: "", size: "", price: "" })
      setOpenProperty(false)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const submitDemand = async () => {
    const { location, size, budget } = demand
    if (!location || !size || !budget) return
    setLoading(true)
    try {
      await fetch("/api/dashboard?action=add_demand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ location, size, budget: parseFloat(budget) }),
      })
      setDemand({ location: "", size: "", budget: "" })
      setOpenDemand(false)
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="grid grid-cols-2 gap-3">
      {/* Add Property */}
      <Dialog open={openProperty} onOpenChange={setOpenProperty}>
        <DialogTrigger asChild>
          <Button variant="outline" className="h-16 flex-col space-y-2 bg-transparent">
            <Plus className="h-5 w-5" />
            <span className="text-xs">Add Property</span>
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Property</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Input placeholder="Title" value={property.title} onChange={(e) => setProperty({ ...property, title: e.target.value })} />
            <Input placeholder="Location" value={property.location} onChange={(e) => setProperty({ ...property, location: e.target.value })} />
            <Input placeholder="Size" value={property.size} onChange={(e) => setProperty({ ...property, size: e.target.value })} />
            <Input placeholder="Price" value={property.price} onChange={(e) => setProperty({ ...property, price: e.target.value })} />
          </div>
          <DialogFooter>
            <Button onClick={submitProperty} disabled={loading}>
              {loading ? "Adding..." : "Submit"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Dealer */}
      <Dialog open={openDealer} onOpenChange={setOpenDealer}>
        <DialogTrigger asChild>
          <Button variant="outline" className="h-16 flex-col space-y-2 bg-transparent">
            <Users className="h-5 w-5" />
            <span className="text-xs">Add Dealer</span>
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>New Dealer</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Input placeholder="Name" value={dealer.name} onChange={(e) => setDealer({ ...dealer, name: e.target.value })} />
            <Input placeholder="Email" value={dealer.email} onChange={(e) => setDealer({ ...dealer, email: e.target.value })} />
            <Input placeholder="Phone" value={dealer.phone} onChange={(e) => setDealer({ ...dealer, phone: e.target.value })} />
            <Input placeholder="Location" value={dealer.location} onChange={(e) => setDealer({ ...dealer, location: e.target.value })} />
          </div>
          <DialogFooter>
            <Button onClick={submitDealer} disabled={loading}>
              {loading ? "Adding..." : "Submit"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Recent Properties */}
      <Dialog open={openRecentProperties} onOpenChange={setOpenRecentProperties}>
        <DialogTrigger asChild>
          <Button variant="outline" className="h-16 flex-col space-y-2 bg-transparent">
            <Home className="h-5 w-5" />
            <span className="text-xs">New Properties</span>
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Recently Added Properties</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2 text-sm">
            {recentProperties.length === 0 ? (
              <p>No recent properties found.</p>
            ) : (
              recentProperties.map((p: any) => (
                <div key={p.id} className="border p-2 rounded-md">
                  <div><strong>{p.title}</strong> - {p.size} - Rs.{p.price}</div>
                  <div className="text-muted-foreground">{p.location}</div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Recent Dealers */}
      <Dialog open={openRecentDealers} onOpenChange={setOpenRecentDealers}>
        <DialogTrigger asChild>
          <Button variant="outline" className="h-16 flex-col space-y-2 bg-transparent">
            <Landmark className="h-5 w-5" />
            <span className="text-xs">New Dealers</span>
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Recently Added Dealers</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2 text-sm">
            {recentDealers.length === 0 ? (
              <p>No recent dealers found.</p>
            ) : (
              recentDealers.map((d: any) => (
                <div key={d.id} className="border p-2 rounded-md">
                  <div><strong>{d.name}</strong></div>
                  {d.email && <div className="text-muted-foreground">{d.email}</div>}
                  {d.phone && <div className="text-muted-foreground">{d.phone}</div>}
                  {d.location && <div className="text-muted-foreground">{d.location}</div>}
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
      {/* Hidden Add Property Trigger for external usage */}
<Dialog open={openProperty} onOpenChange={setOpenProperty}>
  <DialogTrigger asChild>
    <button id="open-add-property" className="hidden" />
  </DialogTrigger>
  <DialogContent>
    {/* your form... */}
  </DialogContent>
</Dialog>


      {/* Add Demand */}
      <Dialog open={openDemand} onOpenChange={setOpenDemand}>
        <DialogTrigger asChild>
          <Button variant="outline" className="h-16 flex-col space-y-2 bg-transparent">
            <Plus className="h-5 w-5" />
            <span className="text-xs">New Demand</span>
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Demand</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Input placeholder="Location" value={demand.location} onChange={(e) => setDemand({ ...demand, location: e.target.value })} />
            <Input placeholder="Size" value={demand.size} onChange={(e) => setDemand({ ...demand, size: e.target.value })} />
            <Input placeholder="Budget" value={demand.budget} onChange={(e) => setDemand({ ...demand, budget: e.target.value })} />
          </div>
          <DialogFooter>
            <Button onClick={submitDemand} disabled={loading}>
              {loading ? "Adding..." : "Submit"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default QuickActions
