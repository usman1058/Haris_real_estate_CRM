'use client';

import SideMenu from "@/app/components/sidemenu/Sidemenu";
import Footer from "@/app/components/Footer/Footer";
import { useSession } from "next-auth/react";
import React from "react";

const Layout = ({ children }: { children: React.ReactNode }) => {
  const { data: session } = useSession();

  if (!session) return <>{children}</>; // Allow login/auth pages to render without layout

  return (
    <div className="flex h-screen bg-gray-50 text-gray-900">
      {/* Sidebar */}
      <div className="w-64 shadow-md bg-white border-r hidden md:block">
        <SideMenu />
      </div>

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4">
          {children}
        </main>

        {/* Footer */}
        <Footer />
      </div>
    </div>
  );
};

export default Layout;
