
'use client';

import React from 'react';
import { styled, useTheme, Theme, CSSObject } from '@mui/material/styles';
import MuiDrawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import HomeIcon from '@mui/icons-material/Home';
import PeopleIcon from '@mui/icons-material/People';
import AddHomeIcon from '@mui/icons-material/MapsHomeWork';
import SearchIcon from '@mui/icons-material/Search';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import LinkIcon from '@mui/icons-material/Link';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import { useMediaQuery } from '@mui/material';
import { signOut } from 'next-auth/react';
import NextLink from 'next/link';

import scss from './Sidemenu.module.scss';


const drawerWidth = 240;
const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));


const menuRouteList = ["analytics", "profile", "settings", ""];

const menuListTranslations = ["Analytics", "Profile", "Settings", "Sign Out"];

const menuItems = [
  { label: 'Dashboard', path: '/Dashboard', icon: <HomeIcon /> },
  { label: 'Dealers', path: '/dealers', icon: <PeopleIcon /> },
  { label: 'Inventory', path: '/inventory', icon: <AddHomeIcon /> },
  { label: 'Add Inventory', path: '/inventory/add', icon: <AddHomeIcon /> },
  { label: 'Buyer Demand', path: '/demand', icon: <SearchIcon /> },
  { label: 'Matches', path: '/matches', icon: <LinkIcon /> },
  { label: 'Settings', path: '/Dashboard/settings', icon: <SettingsIcon /> },
  { label: 'Profile', path: '/Dashboard//profile', icon: <AccountCircleIcon /> },
  { label: 'Sign Out', path: '#signout', icon: <LogoutIcon /> },
];





const Sidemenu = () => {


  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const mobileCheck = useMediaQuery('(max-width:600px)');

  const handleDrawerClose = () => {
    setOpen(!open);
  };

  const handleListItemButtonClick = ( text: string) => {
  text === "Sign Out" ? signOut() : null;
  setOpen(false)
}
  return (



    <MuiDrawer variant="permanent" anchor='left' open={open}
      sx={{
        width: open ? drawerWidth : `calc(${theme.spacing(7)} + 1px)`,

        [`& .MuiDrawer-paper`]: {
          top: mobileCheck ? 0 : 64,
          left: 0,
          flexShrink: 0,
          whiteSpace: 'nowrap',
          boxSizing: 'border-box',

          ...(open && {
            ...openedMixin(theme),
            '& .MuiDrawer-paper': openedMixin(theme),
          }),
          ...(!open && {
            ...closedMixin(theme),
            '& .MuiDrawer-paper': closedMixin(theme),
          }),
        },

      }}
    >
      <DrawerHeader>
        <IconButton sx={{
          position: 'fixed',
      top: 80,
      left: 14,
          zIndex: 1300, // higher than drawer
          backgroundColor: 'white',
          boxShadow: 1,
        }} onClick={handleDrawerClose}>
          {open ? <ChevronLeftIcon /> : <MenuIcon />}
        </IconButton>
      </DrawerHeader>
      <Divider />
      <Divider />

        <List>
          {menuItems.map(({ label, path, icon }) => (
            <ListItem key={label} disablePadding sx={{ display: 'block' }}>
              <NextLink
                href={path === '#signout' ? '' : path}
                className={scss.link}
                passHref
              >
                <ListItemButton
                  onClick={() => handleListItemButtonClick(path)}
                  sx={{
                    minHeight: 48,
                    justifyContent: open ? 'initial' : 'center',
                    px: 2.5,
                  }}
                >
                  <ListItemIcon
                    sx={{
                      minWidth: 0,
                      mr: open ? 2 : 'auto',
                      justifyContent: 'center',
                    }}
                  >
                    {icon}
                  </ListItemIcon>
                  <ListItemText
                    primary={label}
                    sx={{ opacity: open ? 1 : 0 }}
                  />
                </ListItemButton>
              </NextLink>
            </ListItem>
          ))}
        </List>
    </MuiDrawer>
  );
}


export default Sidemenu;


