export { default } from "./DataChart";
