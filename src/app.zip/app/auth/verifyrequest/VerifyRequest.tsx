import React from 'react';

const verifyRequest =() => {
  return (
    <div>
      <h1>VerverifyRequest</h1>
    </div>
  );
}


export default verifyRequest;