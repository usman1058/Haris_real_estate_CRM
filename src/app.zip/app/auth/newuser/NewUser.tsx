import React from 'react';

const newUser =() => {
  return (
    <div>
      <h1>NEWusernewUser</h1>
    </div>
  );
}


export default newUser;